import os

os.system('cmd /k flask run --port=5050')

